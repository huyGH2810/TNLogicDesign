#define MAX_SIM 200

void set_random(Vtop *dut, vluint64_t sim_unit) {

}
