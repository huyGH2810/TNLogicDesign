#define MAX_SIM 10000

void set_random(Vtop *dut, vluint64_t sim_unit) {

}
